About:
    "This is a movie website which shows trailer"
    "of the movies when its poster image is clicked."

Languages Used:
            1. Python
            2. HTML
            3. CSS
            4. Bootstrap

Steps to run the webapp:
                    1. Download the zip file and extract it.
                    2. Open the file Entertainment_center.py using idle.
                    3. Click on Run and then on Run Module.
                    4. Your default browser will open the webapp showing some movies.
                    5. Click on the movie poster to watch the trailer.